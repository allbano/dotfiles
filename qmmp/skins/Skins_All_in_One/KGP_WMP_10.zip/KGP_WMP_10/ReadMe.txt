Winamp Media Player 10

This skin is based entirely on Windows Media Player 10.  If you prefer the appearance of Windows Media Player 10 as I do, then you will like this skin.

Skin created by Matthew Sher.

Thank you for downloading this skin.  Enjoy.