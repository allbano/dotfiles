AlmondXMMSPlayer v1
by Laszlo Simon (laszlo.simon@gmail.com)

My first XMMS skin, made for my Almond metacity theme. 

changelog: 
2006.06.19. - first public release

2006 Laszlo Simon. General Public License