This skin was created based on the original
'eXquisite' design by Puschel. (Don't ask me
who that is, I have no idea). There is not much
left from it now after it went through two edits
but it was still Puschel's idea that started it
so I will let him have a bit of credit for it.

The main change in 'Dragon's Edit 2' is the fact
that it has been re-designed for use with Winamp 2.x
though there are some other minor improvements over
the old 'Dragon's Edit' skin. 

Feel free to use any of the bits for making
your own skin, just try to mention me somewhere
even if it's in a text file like this one. Not
a lot to ask for the many hours I spent making
this, is it? (Try making a skin using only 'Paint'
and you will understand what I mean by 'many hours').

Anyway, hope you like it. If you have any comments
or suggestions for future skin designs mail me at: 

dragon_sdc@mailcity.com
                                  .Red Dragon.

 