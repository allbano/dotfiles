  o                                              o
   ___________________   ___________________  
   \   ___\   ___  \  \  \      \   __\   _ \
    \      \  \ _\  \  \__\  \/  \   /_\    /_
     \_____/\________\_____\______\_____\__\__\
  o                                              o

-----------------------------------------------------
0>-===============================================-<0
|:         Colder Amp by []v[]e (c)                :|
|:                                                 :|
|:   This skin was entirely made in Gimp 1.0.4     :|
|: in a week time. It started as a simple experi-  :|
|: ment of lightning effects, I liked what i got,  :|
|: and  since it  has been a  while since my last  :|
|: skin, i decided to make a new one. I hope u'll  :|
|: like it :) If you have any comments or sugge-   :|
|: stions please mail it to me (mirko82@beotel.yu) :|
|: or send it to my icq #6592117. If you like this :|
|: skin,  visit  my  homepage www.welcome.to/mirko :|
|: to find more skinz by me and to see my page.    :|
|:                                                 :|
|:   You can use this skin freely, distrubute it   :|
|: freely, and modify it but you'll have to men-   :|
|: tion me as original author of the skin. If you  :|
|: modify this skin, please mail it to me, I would :|
|: be happy to see what you done.                  :|
0>-===============================================-<0
-----------------------------------------------------
