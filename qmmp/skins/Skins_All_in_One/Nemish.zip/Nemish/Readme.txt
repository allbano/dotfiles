___ NEMISH ___

 by Stephen Moss

 version 2.0a: March 31, 2001
 original release: December 13, 1999

__________________
NOTES

NEMISH is a futuristic, high-tech, yet somehow retro design.  Not based on anything in particular, it is rather just an attempt to be the best it can be.

I hope you dig it!

__________________
COPYRIGHT

all graphics and design �1999-2000 by Stephen Moss.

__________________
THANKS

Dethvader (rest in peace, bud), and everyone at #skinnerz and Nullsoft.

__________________
CONTACT
  
If you wish, you can check out my homepage.  Dig it at:
http://www.memlo.net

If you'd like to hire me for something, check out my resume and portfolio at:
http://www.retroimg.com

Drop me a line.  You can reach me at:
steve@memlo.net

__________________