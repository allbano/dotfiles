DarkAge - XMMS Skin - Created by Ismael Asensio - 2003

This skin tries to give a different look to the X Multimedia System (XMMS),
rather than the hyper-3D and sci-fi music-boxes usual skins, so it's based on
elements like parchment and fire, giving your favourite player a medieval touch.

Enjoy it!

Created with The GIMP 1.2.3 during July-October, 2003

Thanx to maYam, creator of 'Frihet', the skin I used as a template
and to The Gimp project members because of its great job

//Nice sunrise, Shei
